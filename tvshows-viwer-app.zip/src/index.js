import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import App from "./components/App";
import TvShowDetails from "./components/TvShowDetails";
import paths from "./constants/paths";

ReactDOM.render(
    (
        <Router>
            <Switch>
                <Route path={paths.homePage} exact component={App} />
                <Route path={paths.tvShowDetailsPage} component={TvShowDetails} />
            </Switch>
        </Router>
    ),
    document.getElementById("root"),
    );
