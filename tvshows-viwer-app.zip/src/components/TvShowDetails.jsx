import React from "react";
import PropTypes from 'prop-types';
import urls from "../constants/urls"
import "../css/sainsburrysTheme.css";
import generateImageUrl from "../utils/generateImageUrl"
import generateRating from "../utils/generateRating"
import StarRatingComponent from "react-star-rating-component";

class TvShowDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = { tvShow: {} };
  }

  componentDidMount() {
    fetch(urls.show(this.props.match.params.showId))
        .then(response => response.json())
        .then(tvShow => this.setState({ tvShow } ));
  }

  render() {
    const { title, overview, poster_path, vote_average } = this.state.tvShow;
    return (
        <React.Fragment>
          <div className="tvShowPoster">
            <div>{poster_path && <img alt={title} src={generateImageUrl(poster_path)} />}</div>
          </div>
          <div className="tvShowOverview">
            <h3>{title}</h3>
            <div><StarRatingComponent name={title} value={generateRating(vote_average)} /></div>
            <small>{overview}</small>
          </div>
        </React.Fragment>
    );
  }
}

TvShowDetails.propTypes = {
    match: PropTypes.shape({
        params: PropTypes.shape({
            showId: PropTypes.string.isRequired,
        }).isRequired,
    }).isRequired,
};

export default TvShowDetails;
