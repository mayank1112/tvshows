import React from "react";
import { render } from "@testing-library/react";
import Show from "./TvShowDetails";

it("renders without crashing", () => {
  const mockProps = {
    match: {
      params: {
        showId: "mockId",
      },
    },
  };
  const container = render(<Show {...mockProps} />);
  expect(container).toBeDefined();
});
