import PropTypes from 'prop-types';
import generateImageUrl from "../utils/generateImageUrl";
import StarRatingComponent from "react-star-rating-component";
import generateRating from "../utils/generateRating";
import React from "react";
import urls from "../constants/urls";
import { Link } from "react-router-dom";

const TvShowItem = ({ tvShow: { id, title, poster_path, vote_average} }) => (
    <div className="tvShow">
        <div><img alt={title} src={generateImageUrl(poster_path)} /></div>
        <div><StarRatingComponent editing={true} value={generateRating(vote_average)} /></div>
        <Link to={urls.showDetailsPage(id)}>{title}</Link>
    </div>
);

TvShowItem.propTypes = {
    tvShow: PropTypes.shape({
        id: PropTypes.number.isRequired,
        title: PropTypes.string.isRequired,
        poster_path: PropTypes.string.isRequired,
        vote_average: PropTypes.number.isRequired,
    }).isRequired,
};

export default TvShowItem;