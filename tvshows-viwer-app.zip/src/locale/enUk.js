export default {
  "heading": "TV Bland",
  "bannerTitle": "TV show and web series database.",
  "bannerSubTitle": "Create personalised schedules. Episodes guide, cast, crew and character information.",
  "tvShowPageTitle": "Last Added Shows",
  "homePageTitle": "Last Added Shows"
};