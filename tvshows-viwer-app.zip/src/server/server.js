const Hapi = require('@hapi/hapi');
const routes = require('./routes/api');

const init = async () => {
    const server = Hapi.server({
        port: 8443,
        host: 'localhost',
        routes: {
            cors: true
        },
    });
    server.route(routes);
    await server.start();
};

init();