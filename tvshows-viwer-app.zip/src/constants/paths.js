export default {
    homePage: "/",
    tvShowDetailsPage: "/show/:showId",
};