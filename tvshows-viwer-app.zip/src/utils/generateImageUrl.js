import urls from "../constants/urls";

export default uri => urls.posters + uri;